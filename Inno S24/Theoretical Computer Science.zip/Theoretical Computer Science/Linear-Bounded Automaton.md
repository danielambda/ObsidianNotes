---
tags:
  - Math
  - TCS
---
## Definition
- A non-deterministic [[Turing Machine]] that uses only the tape space occupied by the input is called a linear-bounded automaton (LBA)