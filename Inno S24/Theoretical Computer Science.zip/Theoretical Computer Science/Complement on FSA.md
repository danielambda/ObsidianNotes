---
tags:
  - Math
  - TCS
---
## Definition
- For [[Finite State Automaton (FSA)|FSA]] = $<Q, A, \delta, q_0, F>$ complement FSA is $<Q, A, \delta, q_0, Q\setminus F>$