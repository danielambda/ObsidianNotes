---
tags:
  - TCS
---
## Definition 
- Finite set of symbols